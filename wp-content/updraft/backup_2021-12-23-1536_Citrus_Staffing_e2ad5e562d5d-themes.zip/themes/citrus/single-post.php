<?php

get_header(); ?>
<main id="main" class="site-main" role="main">
  <div class="container">

    <?php the_post_thumbnail( '800-450' );  ?>
    <h2><?php the_title(); ?></h2>
    <div class="container">
      <?php // Start the loop.
      while (have_posts()):
      the_post();      
      the_content();
    ?>
      <?php
      the_post_navigation( array(
        'prev_text'    => '<span class ="prev-next prev">' . __( 'Previous Post', 'citrus' ) . '</span>',
        'next_text'    => '<span class ="prev-next next">' . __( 'Next Post', 'citrus' ) . '</span>',
        'in_same_term' => true,
        'taxonomy'     => 'category',
      ));
      endwhile; 
    ?>
    </div>
  </div>
</main>

<?php get_footer(); ?>